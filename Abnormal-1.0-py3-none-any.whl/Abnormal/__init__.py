#！/user/bin/env python3
# -*- coding:utf-8 -*-

'doc of a test module'

__author__ = 'HeKazhou'

__all__ = ['abnormal']

info='packaging demo'
