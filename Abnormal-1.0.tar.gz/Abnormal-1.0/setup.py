from distutils.core import setup
import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()
setup(
    name='Abnormal',
    version='1.0',
    description='This is a test of the setup',
    author='HeKazhou',
    author_email='501814504@qq.com',
    url='https://github.com/MrKingHe/Abnormal.git',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',

)