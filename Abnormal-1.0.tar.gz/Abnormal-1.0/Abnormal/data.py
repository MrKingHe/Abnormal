from Abnormal.abnormal import helper



class data(object):
    def __init__(self):
        self.__helper=helper()